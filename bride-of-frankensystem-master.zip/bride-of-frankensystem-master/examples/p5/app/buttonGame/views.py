from datetime import datetime
from flask import Blueprint, render_template
from BOFS.util import *
from BOFS.globals import db

buttonGame = Blueprint('buttonGame', __name__,
                        static_url_path='/buttonGame', template_folder='templates', static_folder='static')


@buttonGame.route("/task_button_game", methods=['POST', 'GET'])
@verify_correct_page
@verify_session_valid
def task_button_game():
    if request.method == 'POST':
        log = db.LedButtonLog()
        log.participantID = session['participantID']
        log.timeCompleted = datetime.now()
        log.round = request.form['round']
        log.spacePressed = request.form['buttonPressed'] == 'true'
        log.ledOn = request.form['ledOn'] == 'true'

        db.session.add(log)
        db.session.commit()

        return ""

    if session['condition'] == 0:
        onRatio = 0.75
    else:
        onRatio = 0.25

    return render_template("buttonGame.html", onRatio=onRatio)

