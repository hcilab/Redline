var GameState = {
	START: 0,
	INPUT: 1,
	RESULT: 2
};

// Tunable parameters
var stateStartDuration = 500;
var stateInputDuration = 2500;
var stateResultDuration = 1000;
var onRatio = 0.75;  // Should be set from the template HTML
var maxRounds = 1;  // Should be set from the template HTML


// State variables
var gameState = GameState.START;
var nextStateMillis = 1000;

var buttonPressed = false;
var ledOn = false;
var rounds = 0;

// Graphics
var imgLedOn;
var imgLedOff;
var imgSpacebarPressed;
var imgSpacebarUnpressed;



function setup() {
	var canvas = createCanvas(400, 500);
	canvas.parent('game-window');
	
	imgLedOn = loadImage("buttonGame/images/bulb-on.jpg");
	imgLedOff = loadImage("buttonGame/images/bulb-off.jpg");
	imgSpacebarPressed = loadImage("buttonGame/images/spacebarPressed.png");
	imgSpacebarUnpressed = loadImage("buttonGame/images/spacebarUnpressed.png");
}

function keyTyped() {
	if (gameState != GameState.INPUT) {
		return;
	}
	
	if (key === ' ') {
		buttonPressed = true;
	}
}

function draw() {
	background(255);
	textAlign(CENTER);
	textSize(24);
	fill(0,0,0);

	var ledX = 50;
	var ledY = 0;

	var spaceX = 50;
	var spaceY = 300;
	
	//text("gameState = " + gameState, 200, 30);
	//text("rounds = " + rounds, 200, 70);
	
	if (gameState == GameState.START) {
		text("Get ready...", 200, 150);
	}
	else if (gameState == GameState.INPUT) {
		image(imgLedOff, ledX, ledY);
		
		if (buttonPressed) {
			image(imgSpacebarPressed, spaceX, spaceY);
		} else {
			image(imgSpacebarUnpressed, spaceX, spaceY);
		}
		
	}
	else if (gameState == GameState.RESULT) {
		if (ledOn) {
			image(imgLedOn, ledX, ledY);
		} else {
			image(imgLedOff, ledX, ledY);
		}
	}

	if (millis() > nextStateMillis) {
		if (gameState == GameState.START) {
			gameState = GameState.INPUT;
			nextStateMillis = stateInputDuration + millis();
		}
		else if (gameState == GameState.INPUT) {
			gameState = GameState.RESULT;
			nextStateMillis = stateResultDuration + millis();
			
			var random = Math.random();
			
			if (random <= onRatio) {
				ledOn = true;
			}
		}
		else if (gameState == GameState.RESULT) {
            // Send the data to BOF via a POST request.
			var dataToSend = {
				buttonPressed: buttonPressed,
				ledOn: ledOn,
                round: rounds
			};
			$.post("#", dataToSend);

            rounds++;
			gameState = GameState.START;
			nextStateMillis = stateStartDuration + millis();
			
			buttonPressed = false;
			ledOn = false;

			if (rounds >= maxRounds) {
				setTimeout(function() { window.location.href = "/redirect_next_page"; }, 500);
            }
		}
	}
}