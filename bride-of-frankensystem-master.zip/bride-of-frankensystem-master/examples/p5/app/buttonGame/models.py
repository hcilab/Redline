from datetime import datetime


def create(db):
    class LedButtonLog(db.Model):
        __tablename__ = "led_button_log"
        ledButtonLogID = db.Column(db.Integer, primary_key=True, autoincrement=True)
        participantID = db.Column(db.Integer, db.ForeignKey('participant.participantID'))
        timeCompleted = db.Column(db.DateTime, nullable=False, default=datetime.min)
        round = db.Column(db.Integer, nullable=False, default=0)
        spacePressed = db.Column(db.Boolean, nullable=False, default=0)
        ledOn = db.Column(db.Boolean, nullable=False, default=0)

    return LedButtonLog