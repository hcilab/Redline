# This directory contains a number of starter projects that demostrate various features of BOFS.

## minimal

This is as basic of a project you can get. It contains a single example questionnaire that demonstrates all of the
possible question types.

## unity

This project contains multiple example implementations of Unity games. Each is run separately with its respective
`run.py` file.

This is an example of how to integrate a Unity WebPlayer game into your deployment. It consists of
`bejeweled_webplayer`, which contains functionality relating to displaying and logging a Bejeweled clone,
`navtut_webgl`, which is a simple first-person walking simulator tutorial, and `heartrate`, which demonstrates how to
add heart rate logging to any project.


### bejeweled_webplayer

This consists of a `.cfg` file and a ["blueprint"](http://flask.pocoo.org/docs/0.12/blueprints/), which lives in its own
folder and contains "views" and "models".

In its `models.py` file is a single database model that contains the information needed to record the gameplay stats of
a sessions of Bejeweled. This is utilized when logging. Every `models.py` file should have a `create` method that
returns a [tuple](https://docs.python.org/2/library/functions.html#tuple) of models.

In its `views.py` file is a single route, "game_bejeweled". This route can handle both GET requests (when the
user views the page) and POST requests (when the user submits a "form" -- in this case Unity does this automatically
while the user plays). This allows us to handle both logging the game and displaying the game with one URL. This is
handy because the game can submit the form to the "#" URL.

Bringing all this together is the `bejeweled_webplayer.cfg` file. It starts with a `unity_webplayer_check` that simply
shows the participant a button rendered in Unity's Web Player. This is to ensure that the user doesn't get to far into
the experiment without having Web Player on their system. The next part that's relevant to this example is the
`game_bejeweled` path. This uses the route's GET method to show the game to the user. When the game is over the
`/redirect_next_page` URL is used to send the user to the next page in the `PAGE_LIST` sequence (this can be seen in
`bejeweled.html` -- the Unity side is simply an `Application.ExternalCall("RedirectOnEnd")`.


### heartrate

This extends the `bejeweled_webplayer` example with heart rate logging. This is all done in the `.cfg` file. There is a
`hr_start` page which you place before any task you want to log heart rate for, and then a `hr_end` page, for when you
want that logging to stop.



