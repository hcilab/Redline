from setuptools import setup

setup(
    name = "bride_of_frankensystem",
    version = "0.5.0",
    author = "Colby Johanson",
    author_email = "colby.johanson@usask.ca",
    description = "Used to create online studies",
    license = "BSD",
    keywords = "survey study questionnaire",
    url = "https://git.cs.usask.ca/cgj130/bride-of-frankensystem",
    packages=['BOFS', 'BOFS.default', 'BOFS.admin'],
    package_data={
        'BOFS': [
			'admin/templates/*.*',
            'static/*.*',
            'static/js/*.*',
            'static/jwplayer/*.*',
            'static/unity/*.*',
            'static/unity/WebGLButton/*.*',
            'static/styles/*.*',
            'static/styles/images/*.*',
            'static/styles/images/colorpicker/*.*',
            'static/styles/images/darkness/*.*',
            'static/styles/images/le-frog/*.*',
            'static/styles/images/lightness/*.*',
            'static/styles/images/overcast/*.*',
            'static/styles/images/redmond/*.*',
            'static/styles/images/smoothness/*.*',
            'static/styles/images/start/*.*',
            'static/styles/images/sunny/*.*',
            'templates/*.*',
            'templates/heartrate/*.*',
            'templates/unity/*.*'
        ]
    },
    classifiers=[
        "Development Status :: 3 - Alpha"
    ],
    install_requires=[
        "flask",
        "sqlalchemy",
        "flask-sqlalchemy",
        "flask-socketio"
    ]
)