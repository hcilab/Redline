Installation
============

After installing python 2.7.x:

run: `python setup.py install`

The following packages are also required:

 - `flask`
 - `sqlalchemy`
 - `flask-sqlalchemy`
 - `flask-socketio`
 - `eventlet`
 
If you have pip installed (which comes included with the latest version of Python 2.7.x), you can install each with

 - `pip install <packagename>`
 
_____________________________________________

[For complete documentation, please see the Wiki.](https://git.cs.usask.ca/cgj130/bride-of-frankensystem/wikis/home)